<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class TeamMemberController extends Controller
{
    public function index(Request $request): View
    {
        $team = User::query()
            ->orderByRaw("CASE role WHEN 'admin' THEN 0 WHEN 'manager' THEN 1 ELSE 2 END")
            ->orderBy('name')
            ->get();

        return view('settings.users', compact('team'));
    }

    public function store(Request $request): RedirectResponse
    {
        $roleRules = $request->user()->isAdmin() ? Rule::in(array_keys(User::ROLES)) : Rule::in(['sales']);
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email:rfc', 'max:255', 'unique:users,email'],
            'phone' => ['nullable', 'string', 'max:30'],
            'role' => ['required', $roleRules],
            'password' => ['required', 'string', 'min:10', 'confirmed'],
        ]);
        $data['is_active'] = true;
        $data['timezone'] = $request->user()->timezone ?: 'Asia/Kolkata';
        $data['notifications_enabled'] = true;
        $member = User::create($data);

        return redirect()->route('settings.users')->with('success', $member->name.' has been added to the workspace.');
    }

    public function update(Request $request, User $user): RedirectResponse
    {
        $currentUser = $request->user();
        abort_unless($currentUser->canManageTeam(), 403);
        abort_unless($currentUser->isAdmin() || $user->role === 'sales', 403);
        abort_if($user->isAdmin() && $user->id === $currentUser->id && $request->boolean('is_active') === false, 422, 'You cannot deactivate your own admin account.');
        $roleRules = $currentUser->isAdmin() ? Rule::in(array_keys(User::ROLES)) : Rule::in(['sales']);
        $data = $request->validate([
            'role' => ['required', $roleRules],
            'is_active' => ['required', 'boolean'],
        ]);
        if ($user->isAdmin() && ($data['role'] !== 'admin' || ! $data['is_active'])) {
            $activeAdmins = User::query()->where('role', 'admin')->where('is_active', true)->count();
            abort_if($activeAdmins <= 1, 422, 'At least one active admin is required.');
        }
        $user->update($data);

        return back()->with('success', 'Team member permissions updated.');
    }
}

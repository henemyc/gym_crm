<?php

namespace App\Policies;

use App\Models\Lead;
use App\Models\User;

class LeadPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->is_active;
    }

    public function view(User $user, Lead $lead): bool
    {
        return $user->canManageTeam()
            || $lead->assigned_to === $user->id
            || $lead->followUps()->where('assigned_to', $user->id)->exists();
    }

    public function create(User $user): bool
    {
        return $user->is_active;
    }

    public function update(User $user, Lead $lead): bool
    {
        return $user->canManageTeam() || $lead->assigned_to === $user->id;
    }

    public function delete(User $user, Lead $lead): bool
    {
        return $user->canManageTeam() || $lead->assigned_to === $user->id;
    }

    public function assign(User $user, Lead $lead): bool
    {
        return $user->canManageTeam();
    }
}

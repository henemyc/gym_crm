# GymXBook CRM

A polished, Laravel-only CRM for managing gym sales leads, follow-ups, meetings, and trial sessions. Pages are server-rendered with Blade; there is no React/Vue SPA.

## Stack

- Laravel Framework 12 (`^12.0`; lockfile currently resolves `v12.69.3`)
- PHP `^8.2`; Composer resolves dependencies against PHP 8.2.12 for XAMPP compatibility
- Blade, Eloquent, policies, Form Requests, session authentication
- SQLite by default; MySQL/PostgreSQL-compatible schema
- Vite + local CSS/vanilla JavaScript
- PhpSpreadsheet for CSV, XLS, and XLSX import; streamed CSV export

The version `12.12.2` is a Laravel application-skeleton release, not a `laravel/framework` package version. This project targets the Laravel 12 framework line.

## Local setup (Windows / XAMPP)

Use PHP 8.2 or newer and enable GD in the **CLI** `php.ini` (the path is shown by `php --ini`). PhpSpreadsheet requires GD. In XAMPP's `php.ini`, uncomment `extension=gd`, then restart PowerShell. Check `php -v` and `php -m | findstr /I gd` before installing Composer dependencies.

```powershell
Copy-Item .env.example .env
composer install
php artisan key:generate
if (-not (Test-Path .\database\database.sqlite)) { New-Item -ItemType File .\database\database.sqlite | Out-Null }
php artisan migrate --seed
php artisan serve
```

Open `http://127.0.0.1:8000`. The source package includes the compiled Vite manifest/assets, so a frontend build is not required for the first run. If you change the CSS or JavaScript, install a supported Node.js version (20.19+ or 22.12+) and rebuild. On PowerShell, use the `.cmd` shim to avoid script-policy errors:

```powershell
npm.cmd ci
npm.cmd run build
```

For Vite hot reload during frontend work, run `npm.cmd run dev` in a separate terminal and keep it running. If deployed behind a reverse proxy/load balancer, set `TRUSTED_PROXIES` to the proxy IP/CIDR values so HTTPS links and secure redirects use the public host.

## Demo logins (local seed only)

- Admin: `admin@gymxbook.test` / `password`
- Manager: `manager@gymxbook.test` / `password`
- Sales: `isha@gymxbook.test` / `password`

Change seeded credentials before using a deployed environment. Registration is intentionally closed; workspace users are provisioned by an administrator.

## Included capabilities

Dashboard KPIs and pipeline; searchable/filterable lead list with bulk deletion and CSV export; lead CRUD, assignment, status updates, call/WhatsApp links, notes, and timeline; scheduled/completed follow-ups with outcome, meeting and trial detail; month/week/day calendar; staged spreadsheet import wizard; conversion and activity reports; profile/workspace staff settings; role-aware authorization; Indian demo data.

See [`docs/architecture.md`](docs/architecture.md), [`docs/database-design.md`](docs/database-design.md), and [`docs/design-system.md`](docs/design-system.md).

## Verification

Composer resolved Laravel Framework 12.69.3 and the dependency lock against PHP 8.2.12. On the authoring runner (PHP 8.4.26), fresh SQLite migrations + seeders, route registration, Blade compilation, the Vite production build, and all 15 PHPUnit tests (85 assertions) pass. The package excludes `vendor/`, `.env`, and the local SQLite database; Composer and npm recreate local dependencies as needed.

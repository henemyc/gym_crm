const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const csrfToken = () => $('meta[name="csrf-token"]')?.content || '';

// Responsive navigation drawer.
const sidebar = $('#app-sidebar');
const scrim = $('.sidebar-scrim');
const setSidebar = (open) => {
    sidebar?.classList.toggle('is-open', open);
    scrim?.classList.toggle('is-visible', open);
    document.body.classList.toggle('drawer-open', open);
};
$('[data-sidebar-toggle]')?.addEventListener('click', () => setSidebar(true));
$$('[data-sidebar-close]').forEach((element) => element.addEventListener('click', () => setSidebar(false)));

// Lightweight, accessible header menus.
$$('[data-dropdown-toggle]').forEach((button) => {
    button.addEventListener('click', (event) => {
        event.stopPropagation();
        const panel = document.getElementById(button.dataset.dropdownToggle);
        const willOpen = !panel?.classList.contains('is-open');
        $$('.dropdown-panel.is-open').forEach((menu) => menu.classList.remove('is-open'));
        if (willOpen) panel?.classList.add('is-open');
    });
});
document.addEventListener('click', (event) => {
    if (!event.target.closest('.dropdown-wrap')) {
        $$('.dropdown-panel.is-open').forEach((panel) => panel.classList.remove('is-open'));
    }
});

// Server-rendered forms get a restrained submit state to prevent accidental double taps.
document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || event.defaultPrevented || form.method.toLowerCase() === 'get' || form.hasAttribute('data-no-loading')) return;
    if (form.matches('[data-ajax-lead-form], [data-ajax-lead-status], [data-ajax-lead-delete], [data-ajax-bulk-delete]')) return;
    if (form.matches('[data-confirm]') && form.dataset.confirmConfirmed !== 'true') return;
    const button = form.querySelector('button[type="submit"]:not([form])') || form.querySelector('button[type="submit"]');
    if (!button || button.disabled) return;
    button.classList.add('is-loading');
    button.setAttribute('aria-busy', 'true');
    button.disabled = true;
});

// Existing server-rendered toast messages.
$$('[data-toast]').forEach((toast) => {
    const dismiss = () => {
        toast.classList.add('toast-leaving');
        window.setTimeout(() => toast.remove(), 180);
    };
    $('[data-toast-close]', toast)?.addEventListener('click', dismiss);
    window.setTimeout(dismiss, 5200);
});

// Password visibility on the authentication screen.
$$('[data-toggle-password]').forEach((button) => {
    button.addEventListener('click', () => {
        const input = document.getElementById(button.dataset.togglePassword);
        if (!input) return;
        const showing = input.type === 'text';
        input.type = showing ? 'password' : 'text';
        button.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
    });
});

// Shared confirmation dialog for destructive actions and sensitive form submissions.
const confirmBackdrop = $('[data-confirm-dialog]');
const confirmTitle = $('[data-confirm-title]');
const confirmMessage = $('[data-confirm-message]');
const confirmAccept = $('[data-confirm-accept]');
let confirmResolve = null;
let confirmReturnFocus = null;
const confirmationIsOpen = () => !!confirmBackdrop && !confirmBackdrop.hidden;
const closeConfirmation = (accepted = false) => {
    if (!confirmBackdrop || confirmBackdrop.hidden) return;
    confirmBackdrop.hidden = true;
    confirmBackdrop.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('confirmation-open');
    const resolve = confirmResolve;
    confirmResolve = null;
    if (resolve) resolve(accepted);
    if (confirmReturnFocus?.isConnected) confirmReturnFocus.focus();
    confirmReturnFocus = null;
};
const askForConfirmation = ({ title = 'Are you sure?', message = 'Do you want to continue?', acceptLabel = 'Continue' } = {}) => new Promise((resolve) => {
    if (!confirmBackdrop) { resolve(false); return; }
    if (confirmResolve) closeConfirmation(false);
    confirmResolve = resolve;
    confirmReturnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (confirmTitle) confirmTitle.textContent = title;
    if (confirmMessage) confirmMessage.textContent = message;
    if (confirmAccept) confirmAccept.textContent = acceptLabel;
    confirmBackdrop.hidden = false;
    confirmBackdrop.setAttribute('aria-hidden', 'false');
    document.body.classList.add('confirmation-open');
    window.requestAnimationFrame(() => confirmAccept?.focus());
});
confirmBackdrop?.addEventListener('click', (event) => {
    if (event.target === confirmBackdrop || event.target.closest('[data-confirm-cancel]')) closeConfirmation(false);
    if (event.target.closest('[data-confirm-accept]')) closeConfirmation(true);
});
document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || !form.matches('[data-confirm]')) return;
    if (form.dataset.confirmConfirmed === 'true') { delete form.dataset.confirmConfirmed; return; }
    event.preventDefault();
    askForConfirmation({
        title: form.dataset.confirmTitle || 'Please confirm',
        message: form.dataset.confirm || 'Are you sure you want to continue?',
        acceptLabel: form.dataset.confirmAccept || 'Continue',
    }).then((accepted) => {
        if (!accepted || !form.isConnected) return;
        form.dataset.confirmConfirmed = 'true';
        if (typeof form.requestSubmit === 'function') form.requestSubmit();
        else form.submit();
    });
});

// Leads index: server-rendered rows with JSON-powered search, filtering and pagination.
const leadIndex = $('[data-lead-index]');
const leadFilterForm = $('[data-lead-filter-form]');
const leadResults = $('[data-lead-results]');
const leadFooter = $('[data-lead-footer]');
const leadSpinner = $('[data-lead-spinner]');
const leadResultLabel = $('[data-lead-result-label]');
const leadTotalLabel = $('[data-total-leads]');
const leadExportLink = $('[data-lead-export]');
const filterPanel = $('[data-filter-panel]');
const filterPanelToggle = $('[data-filter-panel-toggle]');
const filterPanelClose = $('[data-filter-panel-close]');
const activeFilterCount = $('[data-active-filter-count]');
const bulkToolbar = $('[data-bulk-toolbar]');
const selectedCountLabel = $('[data-selected-count]');
const selectedHidden = $('[data-selected-hidden]');
const selectAll = $('[data-select-all]');
let leadSearchTimer = 0;
let leadListController = null;
let leadListRequestId = 0;
let leadModalController = null;
let leadModalReturnFocus = null;
let ajaxToastTimer = 0;
let ajaxToastHideTimer = 0;

const ajaxToast = $('[data-ajax-toast]');
const showAjaxToast = (message, kind = 'success') => {
    if (!ajaxToast) return;
    window.clearTimeout(ajaxToastTimer);
    window.clearTimeout(ajaxToastHideTimer);
    ajaxToast.className = `ajax-toast ajax-toast-${kind}`;
    ajaxToast.textContent = message;
    ajaxToast.hidden = false;
    ajaxToast.setAttribute('data-kind', kind);
    ajaxToastTimer = window.setTimeout(() => {
        ajaxToast.classList.add('is-leaving');
        ajaxToastHideTimer = window.setTimeout(() => {
            if (ajaxToast) { ajaxToast.hidden = true; ajaxToast.classList.remove('is-leaving'); }
        }, 180);
    }, 4200);
};

const jsonRequest = async (url, options = {}) => {
    const headers = new Headers(options.headers || {});
    headers.set('Accept', 'application/json');
    headers.set('X-Requested-With', 'XMLHttpRequest');
    if (options.method && !['GET', 'HEAD'].includes(options.method.toUpperCase())) headers.set('X-CSRF-TOKEN', csrfToken());
    const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
    const contentType = response.headers.get('content-type') || '';
    let data = null;
    if (contentType.includes('application/json')) {
        try { data = await response.json(); } catch (_) { data = {}; }
    }
    if (!response.ok || !contentType.includes('application/json')) {
        const error = new Error(data?.message || (response.redirected ? 'Your session may have expired. Sign in again and retry.' : `Unexpected server response (${response.status}).`));
        error.status = response.status || 500;
        error.payload = data;
        throw error;
    }
    return data || {};
};

const errorMessage = (error, fallback = 'Something went wrong. Please try again.') => {
    if (error?.status === 422) return error.payload?.message || 'Please review the entered information and try again.';
    if (error?.status === 403) return error.payload?.message || 'You do not have permission to perform this action.';
    if (error?.status === 419) return 'Your session expired. Refresh the page and try again.';
    return error?.message || fallback;
};

const leadFormUrl = () => {
    if (!leadFilterForm) return null;
    const url = new URL(leadFilterForm.action, window.location.href);
    for (const [name, rawValue] of new FormData(leadFilterForm).entries()) {
        const value = String(rawValue).trim();
        if (value !== '') url.searchParams.set(name, value);
        else url.searchParams.delete(name);
    }
    url.searchParams.delete('page');
    return url;
};

const updateLeadFormFromUrl = (url) => {
    if (!leadFilterForm) return;
    const params = url.searchParams;
    [...leadFilterForm.elements].forEach((field) => {
        if (!field.name || field.type === 'submit' || field.type === 'button') return;
        if (field.type === 'checkbox' || field.type === 'radio') {
            field.checked = params.getAll(field.name).includes(field.value);
            return;
        }
        const value = params.get(field.name);
        if (value !== null) field.value = value;
        else if (field.name === 'per_page') field.value = '15';
        else field.value = '';
    });
    refreshActiveFilterCount();
};

const updateLeadExportLink = (sourceUrl) => {
    if (!leadExportLink) return;
    const exportUrl = new URL(leadExportLink.dataset.leadExportUrl || leadExportLink.href, window.location.href);
    exportUrl.search = '';
    ['q', 'source', 'location', 'priority', 'status', 'from', 'to', 'assigned_to'].forEach((name) => {
        const value = sourceUrl.searchParams.get(name);
        if (value !== null && value !== '') exportUrl.searchParams.set(name, value);
    });
    leadExportLink.href = exportUrl.href;
};

const refreshActiveFilterCount = () => {
    if (!leadFilterForm || !activeFilterCount) return;
    const tracked = ['source', 'location', 'from', 'to', 'assigned_to', 'status', 'priority'];
    const count = tracked.reduce((sum, name) => {
        const field = [...leadFilterForm.elements].find((element) => element.name === name);
        return sum + (field && String(field.value).trim() !== '' ? 1 : 0);
    }, 0);
    activeFilterCount.textContent = String(count);
    activeFilterCount.hidden = count === 0;
};

const setLeadListLoading = (loading) => {
    if (leadSpinner) leadSpinner.hidden = !loading;
    leadFilterForm?.classList.toggle('is-searching', loading);
    leadResults?.setAttribute('aria-busy', loading ? 'true' : 'false');
    if (leadFilterForm) $('[name="q"]', leadFilterForm)?.setAttribute('aria-busy', loading ? 'true' : 'false');
};

const syncLeadSelection = () => {
    if (!leadIndex) return;
    const rowChecks = $$('[data-row-select]', leadIndex);
    const selected = rowChecks.filter((checkbox) => checkbox.checked);
    const count = selected.length;
    if (selectedCountLabel) selectedCountLabel.textContent = String(count);
    if (bulkToolbar) bulkToolbar.hidden = count === 0;
    if (selectAll) {
        selectAll.checked = rowChecks.length > 0 && count === rowChecks.length;
        selectAll.indeterminate = count > 0 && count < rowChecks.length;
        selectAll.disabled = rowChecks.length === 0;
    }
    if (selectedHidden) {
        selectedHidden.replaceChildren();
        selected.forEach((checkbox) => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'ids[]';
            input.value = checkbox.value;
            selectedHidden.append(input);
        });
    }
};

const fetchLeadResults = async (url, historyMode = 'none') => {
    if (!leadIndex || !leadResults || !leadFooter) return;
    if (leadListController) leadListController.abort();
    const controller = new AbortController();
    leadListController = controller;
    const requestId = ++leadListRequestId;
    setLeadListLoading(true);
    try {
        const data = await jsonRequest(url.href, { method: 'GET', signal: controller.signal });
        if (requestId !== leadListRequestId) return;
        leadResults.innerHTML = data.rows || '';
        leadFooter.innerHTML = data.footer || '';
        const total = Number(data.total || 0);
        if (leadTotalLabel) leadTotalLabel.textContent = new Intl.NumberFormat().format(total);
        if (leadResultLabel) leadResultLabel.textContent = `${new Intl.NumberFormat().format(total)} ${total === 1 ? 'lead' : 'leads'}`;
        updateLeadFormFromUrl(url);
        updateLeadExportLink(url);
        if (historyMode === 'push') window.history.pushState({ leads: true }, '', url.href);
        if (historyMode === 'replace') window.history.replaceState({ leads: true }, '', url.href);
        syncLeadSelection();
    } catch (error) {
        if (error.name !== 'AbortError' && requestId === leadListRequestId) showAjaxToast(errorMessage(error, 'Could not refresh your leads.'), 'error');
    } finally {
        if (requestId === leadListRequestId) {
            setLeadListLoading(false);
            leadListController = null;
        }
    }
};

const scheduleLeadSearch = (historyMode = 'replace', delay = 260) => {
    if (!leadIndex || !leadFilterForm) return;
    window.clearTimeout(leadSearchTimer);
    refreshActiveFilterCount();
    leadSearchTimer = window.setTimeout(() => {
        const url = leadFormUrl();
        if (url) fetchLeadResults(url, historyMode);
    }, delay);
};

const resetLeadFilters = () => {
    if (!leadFilterForm) return;
    window.clearTimeout(leadSearchTimer);
    [...leadFilterForm.elements].forEach((field) => {
        if (!field.name || field.type === 'submit' || field.type === 'button') return;
        if (field.name === 'per_page') field.value = '15';
        else if (field.type === 'checkbox' || field.type === 'radio') field.checked = false;
        else field.value = '';
    });
    if (filterPanel) filterPanel.hidden = true;
    filterPanelToggle?.setAttribute('aria-expanded', 'false');
    refreshActiveFilterCount();
    const url = leadFormUrl();
    if (url) fetchLeadResults(url, 'push');
};

if (leadFilterForm) {
    leadFilterForm.addEventListener('submit', (event) => {
        event.preventDefault();
        window.clearTimeout(leadSearchTimer);
        const url = leadFormUrl();
        if (url) fetchLeadResults(url, 'push');
    });
    leadFilterForm.addEventListener('input', (event) => {
        if (event.target.matches('[name="q"]')) scheduleLeadSearch('replace', 280);
    });
    leadFilterForm.addEventListener('change', (event) => {
        if (event.target.matches('select, input[type="date"]')) scheduleLeadSearch('push', 90);
    });
    refreshActiveFilterCount();
}
document.addEventListener('click', (event) => {
    const filterToggle = event.target.closest('[data-filter-panel-toggle]');
    if (filterToggle && filterPanel) {
        event.preventDefault();
        filterPanel.hidden = !filterPanel.hidden;
        filterToggle.setAttribute('aria-expanded', String(!filterPanel.hidden));
        return;
    }
    const filterClose = event.target.closest('[data-filter-panel-close]');
    if (filterClose && filterPanel) {
        event.preventDefault();
        filterPanel.hidden = true;
        filterPanelToggle?.setAttribute('aria-expanded', 'false');
        return;
    }
    if (filterPanel && !filterPanel.hidden && !event.target.closest('[data-filter-panel], [data-filter-panel-toggle]')) {
        filterPanel.hidden = true;
        filterPanelToggle?.setAttribute('aria-expanded', 'false');
    }
    if (event.target.closest('[data-reset-lead-filters], [data-clear-lead-filters]')) {
        event.preventDefault();
        resetLeadFilters();
    }
    const pageLink = event.target.closest('[data-lead-index] .pagination-links a');
    if (pageLink) {
        event.preventDefault();
        window.clearTimeout(leadSearchTimer);
        const url = new URL(pageLink.href, window.location.href);
        fetchLeadResults(url, 'push');
    }
});
window.addEventListener('popstate', () => {
    if (!leadIndex || !leadFilterForm) return;
    window.clearTimeout(leadSearchTimer);
    const url = new URL(window.location.href);
    updateLeadFormFromUrl(url);
    fetchLeadResults(url, 'none');
});

// Accessible lead detail/form modal. Links keep their regular URLs as a no-JS fallback.
const leadDialog = $('[data-lead-dialog]');
const leadDialogContent = $('[data-lead-dialog-content]');
const leadDialogIsOpen = () => !!leadDialog && !leadDialog.hidden;
const showLeadDialog = () => {
    if (!leadDialog) return;
    leadDialog.hidden = false;
    leadDialog.setAttribute('aria-hidden', 'false');
    document.body.classList.add('lead-dialog-open');
};
const closeLeadDialog = () => {
    if (!leadDialog || leadDialog.hidden) return;
    leadModalController?.abort();
    leadModalController = null;
    leadDialog.hidden = true;
    leadDialog.classList.remove('lead-dialog-form-mode');
    leadDialog.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('lead-dialog-open');
    if (leadDialogContent) leadDialogContent.replaceChildren();
    if (leadModalReturnFocus?.isConnected) leadModalReturnFocus.focus();
    else $('[data-lead-filter-form] [name="q"]')?.focus({ preventScroll: true });
    leadModalReturnFocus = null;
};
const openLeadDialog = async (url, opener = document.activeElement) => {
    if (!leadDialog || !leadDialogContent) return;
    if (!leadDialogIsOpen()) leadModalReturnFocus = opener instanceof HTMLElement ? opener : null;
    leadModalController?.abort();
    const controller = new AbortController();
    leadModalController = controller;
    showLeadDialog();
    leadDialog.classList.remove('lead-dialog-form-mode');
    leadDialogContent.innerHTML = '<div class="lead-modal-loading"><span class="lead-spinner-large"></span><span>Loading lead details…</span></div>';
    try {
        const data = await jsonRequest(url, { method: 'GET', signal: controller.signal });
        if (controller.signal.aborted) return;
        leadDialogContent.innerHTML = data.html || '<div class="lead-modal-error">No lead details were returned.</div>';
        leadDialog.classList.toggle('lead-dialog-form-mode', Boolean($('[data-ajax-lead-form]', leadDialogContent)));
        const focusTarget = $('input:not([type="hidden"]), select, textarea, [data-lead-dialog-close], .lead-dialog-actions a', leadDialogContent);
        window.requestAnimationFrame(() => focusTarget?.focus({ preventScroll: true }));
    } catch (error) {
        if (error.name === 'AbortError') return;
        leadDialogContent.innerHTML = `<div class="lead-modal-error"><span class="confirm-dialog-icon"><svg class="icon" width="20" height="20" aria-hidden="true"><use href="#i-alert"></use></svg></span><strong>Couldn’t load this lead</strong><p></p><button class="btn btn-secondary" type="button" data-lead-dialog-close>Close</button></div>`;
        const message = $('.lead-modal-error p', leadDialogContent);
        if (message) message.textContent = errorMessage(error, 'Please try again.');
        $('[data-lead-dialog-close]', leadDialogContent)?.focus();
    }
};
leadDialog?.addEventListener('click', (event) => {
    if (event.target === leadDialog || event.target.closest('[data-lead-dialog-close]')) closeLeadDialog();
});
document.addEventListener('click', (event) => {
    const formLink = event.target.closest('a[data-lead-form-url]');
    const previewLink = event.target.closest('a[data-lead-preview-url]');
    const target = formLink || previewLink;
    if (!target || !leadDialog) return;
    event.preventDefault();
    openLeadDialog(target.dataset.leadFormUrl || target.dataset.leadPreviewUrl || target.href, target);
});

const showFormErrors = (form, errors = {}) => {
    const summary = $('[data-form-errors]', form);
    $$('.field-error', form).forEach((item) => item.remove());
    $$('[aria-invalid="true"]', form).forEach((field) => field.removeAttribute('aria-invalid'));
    const firstMessages = [];
    Object.entries(errors).forEach(([name, messages]) => {
        const message = Array.isArray(messages) ? messages[0] : String(messages);
        firstMessages.push(message);
        const field = [...form.elements].find((element) => element.name === name || element.name === `${name}[]`);
        if (!field) return;
        field.setAttribute('aria-invalid', 'true');
        const wrapper = field.closest('.form-field') || field.parentElement;
        if (!wrapper) return;
        const error = document.createElement('span');
        error.className = 'field-error';
        error.textContent = message;
        wrapper.append(error);
    });
    if (summary) {
        summary.textContent = firstMessages.length ? `Please review the highlighted fields. ${firstMessages[0]}` : 'Please review the entered information.';
        summary.hidden = false;
    }
    $('[aria-invalid="true"]', form)?.focus({ preventScroll: false });
};

const submitLeadForm = async (form) => {
    const button = $('button[type="submit"]', form);
    const originalLabel = button?.innerHTML;
    if (button) { button.disabled = true; button.classList.add('is-loading'); button.setAttribute('aria-busy', 'true'); }
    $$('.field-error', form).forEach((item) => item.remove());
    const summary = $('[data-form-errors]', form);
    if (summary) summary.hidden = true;
    try {
        const data = await jsonRequest(form.action, { method: 'POST', body: new FormData(form) });
        showAjaxToast(data.message || 'Lead saved successfully.');
        if (leadIndex) {
            closeLeadDialog();
            const url = leadFormUrl();
            if (url) fetchLeadResults(url, 'replace');
        } else if (data.url || form.dataset.leadProfileUrl) {
            openLeadDialog(data.url || form.dataset.leadProfileUrl);
        } else closeLeadDialog();
    } catch (error) {
        if (error.status === 422 && error.payload?.errors) showFormErrors(form, error.payload.errors);
        else showAjaxToast(errorMessage(error, 'Could not save this lead.'), 'error');
    } finally {
        if (button?.isConnected) {
            button.disabled = false;
            button.classList.remove('is-loading');
            button.removeAttribute('aria-busy');
            if (originalLabel) button.innerHTML = originalLabel;
        }
    }
};
const submitLeadStatus = async (form) => {
    const button = $('button[type="submit"]', form);
    if (button) { button.disabled = true; button.classList.add('is-loading'); button.setAttribute('aria-busy', 'true'); }
    try {
        const data = await jsonRequest(form.action, { method: 'POST', body: new FormData(form) });
        const select = $('select[name="status"]', form);
        const pill = $('[data-lead-status-pill]');
        if (pill && select) {
            [...pill.classList].forEach((className) => {
                if (className.startsWith('status-') && className !== 'status-pill') pill.classList.remove(className);
            });
            pill.classList.add(`status-${String(data.status || select.value).replaceAll('_', '-')}`);
            pill.textContent = select.selectedOptions[0]?.textContent.trim() || 'Updated';
        }
        showAjaxToast(data.message || 'Lead status updated.');
    } catch (error) {
        showAjaxToast(errorMessage(error, 'Could not update this lead status.'), 'error');
    } finally {
        if (button?.isConnected) { button.disabled = false; button.classList.remove('is-loading'); button.removeAttribute('aria-busy'); }
    }
};

document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.matches('[data-ajax-lead-form]')) {
        event.preventDefault();
        submitLeadForm(form);
    } else if (form.matches('[data-ajax-lead-status]')) {
        event.preventDefault();
        submitLeadStatus(form);
    } else if (form.matches('[data-ajax-lead-delete]')) {
        event.preventDefault();
        deleteLeadForm(form);
    }
});

// Delete forms are always intercepted, confirmed, then sent through JSON/AJAX.
const deleteLeadForm = async (form) => {
    const button = $('button[type="submit"]', form);
    const name = form.dataset.leadDeleteName || 'this lead';
    const accepted = await askForConfirmation({
        title: `Delete “${name}”?`,
        message: 'This lead will be moved to deleted records. You can’t undo this action.',
        acceptLabel: 'Delete lead',
    });
    if (!accepted) return;
    if (button) { button.disabled = true; button.classList.add('is-loading'); button.setAttribute('aria-busy', 'true'); }
    try {
        const data = await jsonRequest(form.action, { method: 'POST', body: new FormData(form) });
        showAjaxToast(data.message || 'Lead moved to deleted records.');
        if (leadIndex) {
            const url = leadFormUrl();
            if (url) fetchLeadResults(url, 'replace');
        } else {
            const profile = $('[data-lead-profile]');
            if (profile) {
                const backUrl = profile.dataset.leadIndexUrl || '/leads';
                profile.innerHTML = `<section class="surface-card delete-success-state"><span class="confirm-dialog-icon"><svg class="icon" width="20" height="20" aria-hidden="true"><use href="#i-check-circle"></use></svg></span><h1>Lead moved to deleted records</h1><p>The record has been removed from your active pipeline.</p><a class="btn btn-primary" href="${backUrl}">Back to leads</a></section>`;
            }
        }
    } catch (error) {
        showAjaxToast(errorMessage(error, 'Could not delete this lead.'), 'error');
    } finally {
        if (button?.isConnected) { button.disabled = false; button.classList.remove('is-loading'); button.removeAttribute('aria-busy'); }
    }
};

const deleteSelectedLeads = async () => {
    const form = $('[data-ajax-bulk-delete]');
    const ids = $$('[data-row-select]:checked', leadIndex || document).map((checkbox) => checkbox.value);
    if (!form || ids.length === 0) return;
    const accepted = await askForConfirmation({
        title: `Delete ${ids.length} selected ${ids.length === 1 ? 'lead' : 'leads'}?`,
        message: 'The selected leads will be moved to deleted records. You can’t undo this action.',
        acceptLabel: `Delete ${ids.length} ${ids.length === 1 ? 'lead' : 'leads'}`,
    });
    if (!accepted) return;
    const trigger = $('[data-bulk-delete-trigger]');
    if (trigger) { trigger.disabled = true; trigger.classList.add('is-loading'); }
    try {
        const data = await jsonRequest(form.action, { method: 'POST', body: new FormData(form) });
        showAjaxToast(data.message || `${ids.length} leads deleted.`);
        syncLeadSelection();
        const url = leadFormUrl();
        if (url) fetchLeadResults(url, 'replace');
    } catch (error) {
        showAjaxToast(errorMessage(error, 'Could not delete the selected leads.'), 'error');
    } finally {
        if (trigger?.isConnected) { trigger.disabled = false; trigger.classList.remove('is-loading'); }
    }
};

document.addEventListener('click', (event) => {
    if (event.target.closest('[data-bulk-delete-trigger]')) {
        event.preventDefault();
        deleteSelectedLeads();
        return;
    }
    if (event.target.closest('[data-clear-selection]')) {
        $$('[data-row-select]', leadIndex || document).forEach((checkbox) => { checkbox.checked = false; });
        if (selectAll) selectAll.checked = false;
        syncLeadSelection();
    }
});
document.addEventListener('change', (event) => {
    if (event.target.matches('[data-select-all]')) {
        $$('[data-row-select]', leadIndex || document).forEach((checkbox) => { checkbox.checked = event.target.checked; });
        syncLeadSelection();
    } else if (event.target.matches('[data-row-select]')) syncLeadSelection();
});
syncLeadSelection();

// Import upload field supports click, keyboard, and drag/drop.
const uploadZone = $('[data-upload-zone]');
const uploadInput = $('[data-upload-input]');
const uploadName = $('[data-upload-name]');
const uploadForm = $('[data-upload-form]');
const showFile = (file) => {
    if (!file || !uploadName) return;
    uploadName.textContent = `${file.name} · ${(file.size / 1024).toFixed(0)} KB`;
    uploadZone?.classList.add('has-file');
    const submit = $('[data-upload-submit]', uploadForm || document);
    if (submit) submit.disabled = false;
};
uploadInput?.addEventListener('change', () => showFile(uploadInput.files?.[0]));
if (uploadZone) {
    uploadZone.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); uploadInput?.click(); }
    });
    ['dragenter', 'dragover'].forEach((name) => uploadZone.addEventListener(name, (event) => {
        event.preventDefault(); uploadZone.classList.add('is-dragging');
    }));
    ['dragleave', 'drop'].forEach((name) => uploadZone.addEventListener(name, (event) => {
        event.preventDefault(); uploadZone.classList.remove('is-dragging');
    }));
    uploadZone.addEventListener('drop', (event) => {
        const file = event.dataTransfer?.files?.[0];
        if (!file || !uploadInput) return;
        const transfer = new DataTransfer();
        transfer.items.add(file);
        uploadInput.files = transfer.files;
        showFile(file);
    });
}

// Record a call or WhatsApp hand-off without interrupting the native phone/chat action.
$$('[data-contact-event][data-activity-url]').forEach((link) => {
    link.addEventListener('click', () => {
        fetch(link.dataset.activityUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': csrfToken() },
            body: JSON.stringify({ event: link.dataset.contactEvent }),
            keepalive: true,
        }).catch(() => { });
    });
});

// On narrow screens the search becomes a compact, tap-to-expand field.
const globalSearch = $('.global-search');
const globalSearchInput = $('.global-search input');
if (globalSearch && globalSearchInput && window.matchMedia('(max-width: 620px)').matches) {
    globalSearch.addEventListener('click', (event) => {
        if (!globalSearch.classList.contains('is-search-open')) {
            event.preventDefault();
            globalSearch.classList.add('is-search-open');
            globalSearchInput.focus();
        }
    });
    document.addEventListener('click', (event) => {
        if (!event.target.closest('.global-search') && document.activeElement !== globalSearchInput) globalSearch.classList.remove('is-search-open');
    });
}

// Shortcut focuses the global lead search.
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        if (confirmationIsOpen()) closeConfirmation(false);
        else if (leadDialogIsOpen()) closeLeadDialog();
        else setSidebar(false);
        if (filterPanel && !filterPanel.hidden) {
            filterPanel.hidden = true;
            filterPanelToggle?.setAttribute('aria-expanded', 'false');
        }
        $$('.dropdown-panel.is-open').forEach((panel) => panel.classList.remove('is-open'));
    }
    if (event.key === 'Tab') {
        const activeDialog = confirmationIsOpen() ? $('[role="alertdialog"]', confirmBackdrop) : leadDialogIsOpen() ? $('[role="dialog"]', leadDialog) : null;
        if (!activeDialog) return;
        const focusable = $$('button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])', activeDialog).filter((item) => item.offsetParent !== null);
        if (focusable.length === 0) { event.preventDefault(); activeDialog.focus(); return; }
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    const isMac = navigator.platform.toUpperCase().includes('MAC');
    if ((isMac ? event.metaKey : event.ctrlKey) && event.key.toLowerCase() === 'k') {
        const search = $('.global-search input');
        if (search) { event.preventDefault(); search.focus(); }
    }
});

// Restore focus and history when returning from an AJAX pagination/filter change.
if (leadIndex && leadFilterForm) updateLeadFormFromUrl(new URL(window.location.href));

// Format local datetime controls with a usable initial value when provided.
$$('[data-auto-focus]').forEach((element) => element.focus());

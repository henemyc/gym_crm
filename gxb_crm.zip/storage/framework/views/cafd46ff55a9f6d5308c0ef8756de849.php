<?php $__env->startSection('title', 'Team & permissions'); ?>
<?php $__env->startSection('page-name', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="breadcrumb"><a href="<?php echo e(route('settings.index')); ?>">Settings</a><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-right','size' => '13']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','size' => '13']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?><span>Team & permissions</span></div>
    <div class="page-heading"><div><div class="eyebrow"><span class="eyebrow-dot"></span> BETTER TOGETHER</div><h1>Team & permissions</h1><p class="page-description">Bring the right people into every lead conversation.</p></div><a class="btn btn-secondary" href="<?php echo e(route('settings.index')); ?>"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-left','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Settings</a></div>
    <div class="settings-layout">
        <section class="surface-card table-card"><div class="card-heading"><div><h2>Workspace members</h2><p><?php echo e($team->where('is_active',true)->count()); ?> active team members</p></div><span class="status-pill status-orange"><?php echo e($team->count()); ?> people</span></div><div class="team-table-wrap"><table class="team-table"><thead><tr><th>Person</th><th>Role</th><th>Status</th><th>Change access</th></tr></thead><tbody><?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><div class="team-member"><span class="avatar avatar-soft avatar-<?php echo e(['orange','blue','green','purple','rose'][$loop->index % 5]); ?>"><?php echo e($member->initials()); ?></span><span><strong><?php echo e($member->name); ?> <?php if($member->id === auth()->id()): ?><span class="table-muted">(you)</span><?php endif; ?></strong><small><?php echo e($member->email); ?><?php echo e($member->phone ? ' · '.$member->phone : ''); ?></small></span></div></td><td><span class="role-badge <?php echo e($member->role); ?>"><?php echo e(\App\Models\User::ROLES[$member->role] ?? 'Member'); ?></span></td><td><span class="status-pill <?php echo e($member->is_active ? 'status-converted' : 'status-lost'); ?>"><?php echo e($member->is_active ? 'Active' : 'Inactive'); ?></span></td><td><?php if(auth()->user()->isAdmin() || ($member->role === 'sales' && $member->id !== auth()->id())): ?><form class="team-permission-form" method="POST" action="<?php echo e(route('settings.users.update', $member)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><select class="filter-select" name="role" aria-label="Role for <?php echo e($member->name); ?>"><?php $__currentLoopData = \App\Models\User::ROLES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(auth()->user()->isAdmin() || $key==='sales'): ?><option value="<?php echo e($key); ?>" <?php if($member->role === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><select class="filter-select" name="is_active" aria-label="Access for <?php echo e($member->name); ?>"><option value="1" <?php if($member->is_active): echo 'selected'; endif; ?>>Active</option><option value="0" <?php if(! $member->is_active): echo 'selected'; endif; ?>>Inactive</option></select><button class="btn btn-secondary btn-sm" type="submit">Save</button></form><?php else: ?><span class="table-muted">Managed by admin</span><?php endif; ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table></div></section>
        <aside class="surface-card form-card"><div class="card-heading" style="padding:0 0 15px"><div><h2>Add a teammate</h2><p>They’ll use these details to sign in.</p></div></div><?php if($errors->any()): ?><div class="form-error-summary"><?php echo e($errors->first()); ?></div><?php endif; ?><form method="POST" action="<?php echo e(route('settings.users.store')); ?>"><?php echo csrf_field(); ?><div class="form-field"><label class="field-label" for="new-name">Full name</label><input class="form-control" id="new-name" name="name" value="<?php echo e(old('name')); ?>" required></div><div class="form-field" style="margin-top:10px"><label class="field-label" for="new-email">Work email</label><input class="form-control" id="new-email" name="email" type="email" value="<?php echo e(old('email')); ?>" required></div><div class="form-field" style="margin-top:10px"><label class="field-label" for="new-phone">Phone <span class="table-muted">· optional</span></label><input class="form-control" id="new-phone" name="phone" value="<?php echo e(old('phone')); ?>"></div><div class="form-field" style="margin-top:10px"><label class="field-label" for="new-role">Role</label><select class="select-control" id="new-role" name="role" required><?php $__currentLoopData = \App\Models\User::ROLES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(auth()->user()->isAdmin() || $key==='sales'): ?><option value="<?php echo e($key); ?>" <?php if(old('role','sales')===$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><div class="form-field" style="margin-top:10px"><label class="field-label" for="new-password">Temporary password</label><input class="form-control" type="password" id="new-password" name="password" autocomplete="new-password" required><span class="field-hint">At least 10 characters; ask them to update it after sign-in.</span></div><div class="form-field" style="margin-top:10px"><label class="field-label" for="new-password-confirmation">Confirm password</label><input class="form-control" type="password" id="new-password-confirmation" name="password_confirmation" autocomplete="new-password" required></div><div class="form-actions"><button class="btn btn-primary" type="submit"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','size' => '15']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','size' => '15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Add teammate</button></div></form></aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Laravel_Project\gxb_crm\resources\views/settings/users.blade.php ENDPATH**/ ?>
# GymXBook CRM design system

## Direction

A calm, light CRM canvas with the data density of a revenue workspace, not a generic admin template. Inspiration: HubSpot's sales workflow clarity, Linear's restraint, and fintech dashboard hierarchy. Use compact uppercase utility labels sparingly, large readable values, crisp alignment, soft surfaces, fine borders, and one clear Flame Orange action at a time.

## Tokens

- Brand: Flame Orange `#FF5A1F`; hover `#EA4B14`; pale accent `#FFF0E9`.
- Canvas `#F7F8FA`; surface `#FFFFFF`; text `#1F2937`; muted `#7B8494`; border `#E8EBF0`.
- Success `#148A62`; warning `#D38B12`; danger `#D54B4B`; info `#4273D8`.
- Sidebar width 248px; content max 1500px; 8px spacing rhythm; 12–16px corner radius; restrained shadows.
- Typography uses local system sans stacks (no remote font dependency), tabular numerals for metrics, and clear focus rings.

## Interaction principles

- Responsive sidebar becomes a drawer on small screens; tables retain readable horizontal scroll rather than crushing columns.
- Loading, empty, error, and success states use the same surface/spacing language.
- Native form controls remain keyboard-accessible; state is not communicated by color alone.
- Motion is subtle, short, and disabled under `prefers-reduced-motion`.
